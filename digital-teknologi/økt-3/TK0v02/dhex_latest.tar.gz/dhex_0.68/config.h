
// size for the hex buffer
#define	BUFFERSIZE	(1<<20)
#define	BUFFERMARGIN	(BUFFERSIZE/4)

#define	CHANGEBUFSIZE	(1<<16)	


// size for text strings, like from the config-file
#define	TEXTSTRINGSIZE	128
