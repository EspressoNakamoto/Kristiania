#ifndef	GPL_H
#define	GPL_H
void warte();
void print_gpl();
#endif

