#ifndef	CONFIGFILE_H
#define	CONFIGFILE_H
#include <stdio.h>
#include <stdlib.h>
#include "machine_type.h"
#include "output.h"

int readconfigfile(tOutput* output,char* filename);
#endif

